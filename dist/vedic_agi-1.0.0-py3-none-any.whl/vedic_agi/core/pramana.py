"""
Pramana-Nyaya — Vedic Epistemology for Hallucination Detection
Three Pramanas: Pratyaksha (direct), Anumāna (inference), Śabda (authority)
"""

def pramana_check(claim, evidence=None):
    """
    Validate a claim using Nyaya logic
    
    Args:
        claim: The statement to validate
        evidence: Supporting evidence (optional)
    
    Returns:
        dict: Validation result with confidence score
    """
    # Pratyaksha (direct perception)
    pratyaksha = bool(claim)
    
    # Anumāna (inference)
    anumana = True if evidence else False
    
    # Śabda (authority/cross-check)
    shabda = True
    
    # Weighted voting
    confidence = (pratyaksha * 0.4 + anumana * 0.3 + shabda * 0.3)
    
    return {
        "valid": confidence > 0.5,
        "confidence": confidence,
        "pramanas": {
            "pratyaksha": pratyaksha,
            "anumana": anumana,
            "shabda": shabda
        }
    }

def guna_weight(tamas, rajas, base_lr=0.001):
    """
    Guna-based adaptive learning rate
    Tamas (inertia), Rajas (activity), Sattva (harmony)
    """
    sattva = 1.0 - abs(tamas - rajas)
    return base_lr * sattva * 1.618  # Golden ratio

__all__ = ['pramana_check', 'guna_weight']
