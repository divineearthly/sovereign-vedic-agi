"""
Urdhva-Tiryagbhyam — Vedic Vertical and Crosswise Multiplication
"""

def urdhva_multiply(a, b):
    """
    Multiply two numbers using Urdhva sutra
    """
    a_str, b_str = str(a), str(b)
    a_len, b_len = len(a_str), len(b_str)
    
    # Simple implementation
    result = [0] * (a_len + b_len)
    
    for i in range(a_len - 1, -1, -1):
        carry = 0
        for j in range(b_len - 1, -1, -1):
            pos = i + j + 1
            product = int(a_str[i]) * int(b_str[j]) + result[pos] + carry
            result[pos] = product % 10
            carry = product // 10
        result[i] += carry
    
    return int(''.join(map(str, result)).lstrip('0'))

__all__ = ['urdhva_multiply']
